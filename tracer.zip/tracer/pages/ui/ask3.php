﻿<!DOCTYPE html>
<html>

<?php

session_start();
include '../../model/set.php';
//cek apakah sudah login
if(empty($_SESSION['npm'])){
   header('location:../../index.php');//jika belum login jangan lanjut..
}
?>
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Unikama | Tracer Study</title>
    <!-- Favicon-->
    <link rel="icon" href="../../favicon.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="../../plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="../../plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="../../plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="../../css/style.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="../../css/themes/all-themes.css" rel="stylesheet" />
	
	
	
</head>

<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="START TYPING...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
    <nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="javascript:void(0);" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="javascript:void(0);" class="bars"></a>
                <a class="navbar-brand" href="../../index.php">Unikama - Tracer Study</a>
            </div>
            
        </div>
    </nav>
    <!-- #Top Bar -->
    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="user-info">
                <div class="image">
                    <img src="../../images/logo.png" width="48" height="48" alt="User" />
                </div>
                <div class="info-container">
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['nama'] ?></div>
                    <div class="email"><?php echo $_SESSION['email'] ?></div>
                    
                </div>
            </div>
            <!-- #User Info -->
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    
                    <li>
                        <a href="../../index.php">
                            <i class="material-icons">home</i>
                            <span>Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="../../model/log.php?submit=out">
                            <i class="material-icons">arrow_back</i>
                            <span>Keluar</span>
                        </a>
                    </li>
                </ul>
            </div>
            <!-- #Menu -->
            <!-- Footer -->
            <div class="legal">
                <div class="copyright">
                    &copy; 2019 <a href="javascript:void(0);">Blackantcreative</a>
                </div>
            </div>
            <!-- #Footer -->
        </aside>
        <!-- #END# Left Sidebar -->
        <!-- Right Sidebar -->
        
        <!-- #END# Right Sidebar -->
    

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2></h2>
            </div>

            <!-- Basic Alerts -->
            <div class="row clearfix">
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box-4 hover-zoom-effect">
                        <div class="icon">
                            <i class="material-icons col-pink">question_answer</i>
                        </div>
                        <div class="content">
                            <div class="text">QUESTIONNAIRE</div>
                            <div class="number">3 of 18</div>
                        </div>
                    </div>

                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
						
                        
                        <div class="body">
                            
                            <div class="alert alert-info">
                                <strong>Question</strong>
                            </div>
							<!-- Menampilkan pesan error -->
							<?php if(isset($_GET["error"])) { ?>
							<div class="alert alert-warning alert-dismissible" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                Data tidak boleh kosong
                            </div>
							<?php } ?>
							<form id="sign_up" method="get" action="../../model/process.php">
								<div class="msg">
								Bagaimana anda mencari pekerjaan tersebut ? Jawaban bisa lebih dari satu
								</div><br/>
								<div class="input-group">
								
								<div class="demo-checkbox">
                                <input type="checkbox" name="f401" id="md_checkbox_21" value="1" class="filled-in chk-col-red" />
                                <label for="md_checkbox_21">Melalui iklan di koran / majalah, brosur</label><br/>
                                <input type="checkbox" name="f402" id="md_checkbox_22" value="1" class="filled-in chk-col-pink" />
                                <label for="md_checkbox_22">Melamar ke perusahaan tanpa mengetahui lowongan yang ada</label><br/>
                                <input type="checkbox" name="f403" id="md_checkbox_23" value="1" class="filled-in chk-col-purple" />
                                <label for="md_checkbox_23">Pergi ke bursa / pameran kerja</label><br/>
                                <input type="checkbox" name="f404" id="md_checkbox_24" value="1" class="filled-in chk-col-deep-purple" />
                                <label for="md_checkbox_24">Mencari lewat internet / iklan online / milis</label><br/>
                                <input type="checkbox" name="f405" id="md_checkbox_25" value="1" class="filled-in chk-col-indigo" />
                                <label for="md_checkbox_25">Dihubungi oleh perusahaan</label><br/>
                                <input type="checkbox" name="f406" id="md_checkbox_26" value="1" class="filled-in chk-col-blue" />
                                <label for="md_checkbox_26">Menghubungi Kemenakertrans</label><br/>
                                <input type="checkbox" name="f407" id="md_checkbox_27" value="1" class="filled-in chk-col-light-blue" />
                                <label for="md_checkbox_27">Menghubungi agen tenaga kerja komersial/swasta</label><br/>
                                <input type="checkbox" name="f408" id="md_checkbox_28" value="1" class="filled-in chk-col-cyan" />
                                <label for="md_checkbox_28">Memeroleh informasi dari pusat/kantor pengembangan karir fakultas/universitas</label><br/>
                                <input type="checkbox" name="f409" id="md_checkbox_29" value="1" class="filled-in chk-col-teal" />
                                <label for="md_checkbox_29">Menghubungi kantor kemahasiswaan/hubungan alumni</label><br/>
                                <input type="checkbox" name="f410" id="md_checkbox_30" value="1" class="filled-in chk-col-green" />
                                <label for="md_checkbox_30">Membangun jejaring (network) sejak masih kuliah</label><br/>
                                <input type="checkbox" name="f411" id="md_checkbox_31" value="1" class="filled-in chk-col-light-green" />
                                <label for="md_checkbox_31">Melalui relasi (Misalnya dosen, orangtua, saudara, teman, dll)</label><br/>
                                <input type="checkbox" name="f412" id="md_checkbox_32" value="1" class="filled-in chk-col-lime" />
                                <label for="md_checkbox_32">Membangun bisnis sendiri</label><br/>
                                <input type="checkbox" name="f413" id="md_checkbox_33" value="1" class="filled-in chk-col-yellow" />
                                <label for="md_checkbox_33">Melalui penempatan kerja atau magang</label><br/>
                                <input type="checkbox" name="f414" id="md_checkbox_34" value="1" class="filled-in chk-col-amber" />
                                <label for="md_checkbox_34">Bekerja ditempat yang sama dengan tempat kerja semasa kuliah</label><br/>
                                <input type="checkbox" name="f415" id="md_checkbox_35" value="1" class="filled-in chk-col-orange" />
                                <label for="md_checkbox_35">Lainnya</label><br/>
                                <input type="checkbox" name="f416" id="md_checkbox_36" value="1" class="filled-in chk-col-deep-orange" />
                                <div class="form-line">
								<input type="text" class="form-control" name="input" placeholder="jika ada lainnya sebutkan">
								</div>
                                
								</div>
									
									
								</div>

								<button class="btn btn-block btn-lg bg-pink waves-effect" type="submit" name="proses" value="3">Selanjutnya</button>

								<div class="row m-t-20 m-b--5 align-center">
									
								</div>
							</form>
							
                            
                        </div>
						
                    </div>
                </div>
            </div>
            <!-- #END# Basic Alerts -->
           
           
            
        </div>
    </section>

    <!-- Jquery Core Js -->
    <script src="../../plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="../../plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="../../plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="../../plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="../../plugins/node-waves/waves.js"></script>

    <!-- Custom Js -->
    <script src="../../js/admin.js"></script>

    <!-- Demo Js -->
    <script src="../../js/demo.js"></script>
</body>

</html>
