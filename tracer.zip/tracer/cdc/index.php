<html>
<head>
	<link href="../css/bootstrap.css" rel="stylesheet" media="screen">
	<link href="../css/bootstrap-responsive.css" rel="stylesheet">
	<script src="../js/jquery.js"></script> 
	<script src="../js/bootstrap.js"></script> 
	</head>
<body>

<?php
session_start();
include 'model/set.php';
//cek apakah user sudah melakukan login sebelumnya 

if(!empty($_SESSION['userid'])){
	if($_SESSION['lvl']=='klien'){
		header("location:../pages/charts/chartjs.php");
		
	}else{
		header("location:../pages/forms/Adds.php");
	}
	}else{
		header("location:../pages/examples/sign-in-member.php");
	}
	
	
?>

