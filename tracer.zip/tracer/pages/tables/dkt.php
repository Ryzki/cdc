﻿<!DOCTYPE html>
<html>
<?php

session_start();
include '../../model/set.php';


if(isset($_SESSION['userid'])){
	if(isset($_SESSION['psw'])){
	//header('location:../../cdc/index.php');//jika belum login jangan lanjut..
	
?>
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Unikama | Tracer Study</title>
    <!-- Favicon-->
    <link rel="icon" href="../../favicon.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="../../plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="../../plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="../../plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- JQuery DataTable Css -->
    <link href="../../plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css" rel="stylesheet">

    <!-- Custom Css -->
    <link href="../../css/style.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="../../css/themes/all-themes.css" rel="stylesheet" />
</head>

<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="START TYPING...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
    <nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="javascript:void(0);" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="javascript:void(0);" class="bars"></a>
               <a class="navbar-brand" href="../../cdc/index.php">Unikama - Tracer Study</a>
            </div>
            
        </div>
    </nav>
    <!-- #Top Bar -->
    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="user-info">
                <div class="image">
                    <img src="../../images/logo.png" width="48" height="48" alt="User" />
                </div>
                <div class="info-container">
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Hello , <?php echo $_SESSION['userid'] ?></div>
                    
                    
                </div>
            </div>
            <!-- #User Info -->
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                   
                    <li>
                        <a href="../../cdc/index.php">
                            <i class="material-icons">home</i>
                            <span>Home</span>
                        </a>
                    </li>
					<li>
                        <a href="../../pages/forms/editors.php">
                            <i class="material-icons">school</i>
                            <span>Sambutan</span>
                        </a>
                    </li>
					<li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">import_contacts</i>
                            <span>Program Studi</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="../../pages/tables/ListProdi.php">Daftar Prodi</a>
                            </li>
                            <li>
                                <a href="../../pages/forms/AddProdi.php">Tambah Prodi</a>
                            </li>
                        </ul>
                    </li>
					<li class="active">
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">group</i>
                            <span>Alumni</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="../../pages/tables/main.php">Status</a>
                            </li>
                            <li>
                                <a href="../../pages/tables/dkt.php">Dikti</a>
                            </li>
							<li>
                                <a href="../../pages/tables/AddAlumni.php">Tambah Alumni</a>
                            </li>
                        </ul>
                    </li>
					<li>
                        <a href="../../pages/forms/updl.php">
                            <i class="material-icons">unarchive</i>
                            <span>Upload data</span>
                        </a>
                    </li>
					<li>
                        <a href="../../pages/charts/chartjs.php">
                            <i class="material-icons">pie_chart</i>
                            <span>Grafik</span>
                        </a>
                    </li>
					
                    <li>
                        <a href="../../model/log.php?submit=outmember">
                            <i class="material-icons">input</i>
                            <span>Keluar</span>
                        </a>
                    </li>
                    
                </ul>
            </div>
            <!-- #Menu -->
            <!-- Footer -->
             
            <!-- #Footer -->
        </aside>
        <!-- #END# Left Sidebar -->
        <!-- Right Sidebar -->
        <aside id="rightsidebar" class="right-sidebar">
            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                <li role="presentation" class="active"><a href="#skins" data-toggle="tab">SKINS</a></li>
                <li role="presentation"><a href="#settings" data-toggle="tab">SETTINGS</a></li>
            </ul>
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane fade in active in active" id="skins">
                    <ul class="demo-choose-skin">
                        <li data-theme="red" class="active">
                            <div class="red"></div>
                            <span>Red</span>
                        </li>
                        <li data-theme="pink">
                            <div class="pink"></div>
                            <span>Pink</span>
                        </li>
                        <li data-theme="purple">
                            <div class="purple"></div>
                            <span>Purple</span>
                        </li>
                        <li data-theme="deep-purple">
                            <div class="deep-purple"></div>
                            <span>Deep Purple</span>
                        </li>
                        <li data-theme="indigo">
                            <div class="indigo"></div>
                            <span>Indigo</span>
                        </li>
                        <li data-theme="blue">
                            <div class="blue"></div>
                            <span>Blue</span>
                        </li>
                        <li data-theme="light-blue">
                            <div class="light-blue"></div>
                            <span>Light Blue</span>
                        </li>
                        <li data-theme="cyan">
                            <div class="cyan"></div>
                            <span>Cyan</span>
                        </li>
                        <li data-theme="teal">
                            <div class="teal"></div>
                            <span>Teal</span>
                        </li>
                        <li data-theme="green">
                            <div class="green"></div>
                            <span>Green</span>
                        </li>
                        <li data-theme="light-green">
                            <div class="light-green"></div>
                            <span>Light Green</span>
                        </li>
                        <li data-theme="lime">
                            <div class="lime"></div>
                            <span>Lime</span>
                        </li>
                        <li data-theme="yellow">
                            <div class="yellow"></div>
                            <span>Yellow</span>
                        </li>
                        <li data-theme="amber">
                            <div class="amber"></div>
                            <span>Amber</span>
                        </li>
                        <li data-theme="orange">
                            <div class="orange"></div>
                            <span>Orange</span>
                        </li>
                        <li data-theme="deep-orange">
                            <div class="deep-orange"></div>
                            <span>Deep Orange</span>
                        </li>
                        <li data-theme="brown">
                            <div class="brown"></div>
                            <span>Brown</span>
                        </li>
                        <li data-theme="grey">
                            <div class="grey"></div>
                            <span>Grey</span>
                        </li>
                        <li data-theme="blue-grey">
                            <div class="blue-grey"></div>
                            <span>Blue Grey</span>
                        </li>
                        <li data-theme="black">
                            <div class="black"></div>
                            <span>Black</span>
                        </li>
                    </ul>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="settings">
                    <div class="demo-settings">
                        <p>GENERAL SETTINGS</p>
                        <ul class="setting-list">
                            <li>
                                <span>Report Panel Usage</span>
                                <div class="switch">
                                    <label><input type="checkbox" checked><span class="lever"></span></label>
                                </div>
                            </li>
                            <li>
                                <span>Email Redirect</span>
                                <div class="switch">
                                    <label><input type="checkbox"><span class="lever"></span></label>
                                </div>
                            </li>
                        </ul>
                        <p>SYSTEM SETTINGS</p>
                        <ul class="setting-list">
                            <li>
                                <span>Notifications</span>
                                <div class="switch">
                                    <label><input type="checkbox" checked><span class="lever"></span></label>
                                </div>
                            </li>
                            <li>
                                <span>Auto Updates</span>
                                <div class="switch">
                                    <label><input type="checkbox" checked><span class="lever"></span></label>
                                </div>
                            </li>
                        </ul>
                        <p>ACCOUNT SETTINGS</p>
                        <ul class="setting-list">
                            <li>
                                <span>Offline</span>
                                <div class="switch">
                                    <label><input type="checkbox"><span class="lever"></span></label>
                                </div>
                            </li>
                            <li>
                                <span>Location Permission</span>
                                <div class="switch">
                                    <label><input type="checkbox" checked><span class="lever"></span></label>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </aside>
        <!-- #END# Right Sidebar -->
    </section>

    <section class="content">
        <div class="container-fluid">
            
            <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                DATA UPLOAD KE DIKTI
                            </h2>
							<ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                   
                                </li>
                            </ul>
                            
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                    <thead>
                                        <tr>
                                            <th>kdptimsmh</th>
                                            <th>kdpstmsmh</th>
                                            <th>nimhsmsmh</th>
                                            <th>nmmhsmsmh</th>
                                            <th>telpomsmh</th>
                                            <th>emailmsmh</th>
											<th>tahun_lulus</th>
											<th>f21</th>
											<th>f22</th>
											<th>f23</th>
											<th>f24</th>
											<th>f25</th>
											<th>f26</th>
											<th>f27</th>
											<th>f301</th>
											<th>f302</th>
											<th>f303</th>
											<th>f401</th>
											<th>f402</th>
											<th>f403</th>
											<th>f404</th>
											<th>f405</th>
											<th>f406</th>
											<th>f407</th>
											<th>f408</th>
											<th>f409</th>
											<th>f410</th>
											<th>f411</th>
											<th>f412</th>
											<th>f413</th>
											<th>f414</th>
											<th>f415</th>
											<th>f416</th>
											<th>f6</th>
											<th>f501</th>
											<th>f502</th>
											<th>f503</th>
											<th>f7</th>
											<th>f7a</th>
											<th>f8</th>
											<th>f901</th>
											<th>f902</th>
											<th>f903</th>
											<th>f904</th>
											<th>f905</th>
											<th>f906</th>
											<th>f1001</th>
											<th>f1002</th>
											<th>f1101</th>
											<th>f1102</th>
											<th>f1201</th>
											<th>f1202</th>
											<th>f1301</th>
											<th>f1302</th>
											<th>f1303</th>
											<th>f14</th>
											<th>f15</th>
											<th>f1601</th>
											<th>f1602</th>
											<th>f1603</th>
											<th>f1604</th>
											<th>f1605</th>
											<th>f1606</th>
											<th>f1607</th>
											<th>f1608</th>
											<th>f1609</th>
											<th>f1610</th>
											<th>f1611</th>
											<th>f1612</th>
											<th>f1613</th>
											<th>f1614</th>
											<th>f1701</th>
											<th>f1702b</th>
											<th>f1703</th>
											<th>f1704b</th>
											<th>f1705</th>
											<th>f1705a</th>
											<th>f1706</th>
											<th>f1706ba</th>
											<th>f1707</th>
											<th>f1708b</th>
											<th>f1709</th>
											<th>f1710b</th>
											<th>f1711</th>
											<th>f1711a</th>
											<th>f1712b</th>
											<th>f1712a</th>
											<th>f1713</th>
											<th>f1714b</th>
											<th>f1715</th>
											<th>f1716b</th>
											<th>f1717</th>
											<th>f1718b</th>
											<th>f1719</th>
											<th>f1720b</th>
											<th>f1721</th>
											<th>f1722b</th>
											<th>f1723</th>
											<th>f1724b</th>
											<th>f1725</th>
											<th>f1726b</th>
											<th>f1727</th>
											<th>f1728b</th>
											<th>f1729</th>
											<th>f1730b</th>
											<th>f1731</th>
											<th>f1732b</th>
											<th>f1733</th>
											<th>f1734b</th>
											<th>f1735</th>
											<th>f1736b</th>
											<th>f1737</th>
											<th>f1737a</th>
											<th>f1738</th>
											<th>f1738ba</th>
											<th>f1739</th>
											<th>f1740b</th>
											<th>f1741</th>
											<th>f1742b</th>
											<th>f1743</th>
											<th>f1744b</th>
											<th>f1745</th>
											<th>f1746b</th>
											<th>f1747</th>
											<th>f1748b</th>
											<th>f1749</th>
											<th>f1750b</th>
											<th>f1751</th>
											<th>f1752b</th>
											<th>f1753</th>
											<th>f1754b</th>
											<th>akreditasi</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>kdptimsmh</th>
                                            <th>kdpstmsmh</th>
                                            <th>nimhsmsmh</th>
                                            <th>nmmhsmsmh</th>
                                            <th>telpomsmh</th>
                                            <th>emailmsmh</th>
											<th>tahun_lulus</th>
											<th>f21</th>
											<th>f22</th>
											<th>f23</th>
											<th>f24</th>
											<th>f25</th>
											<th>f26</th>
											<th>f27</th>
											<th>f301</th>
											<th>f302</th>
											<th>f303</th>
											<th>f401</th>
											<th>f402</th>
											<th>f403</th>
											<th>f404</th>
											<th>f405</th>
											<th>f406</th>
											<th>f407</th>
											<th>f408</th>
											<th>f409</th>
											<th>f410</th>
											<th>f411</th>
											<th>f412</th>
											<th>f413</th>
											<th>f414</th>
											<th>f415</th>
											<th>f416</th>
											<th>f6</th>
											<th>f501</th>
											<th>f502</th>
											<th>f503</th>
											<th>f7</th>
											<th>f7a</th>
											<th>f8</th>
											<th>f901</th>
											<th>f902</th>
											<th>f903</th>
											<th>f904</th>
											<th>f905</th>
											<th>f906</th>
											<th>f1001</th>
											<th>f1002</th>
											<th>f1101</th>
											<th>f1102</th>
											<th>f1201</th>
											<th>f1202</th>
											<th>f1301</th>
											<th>f1302</th>
											<th>f1303</th>
											<th>f14</th>
											<th>f15</th>
											<th>f1601</th>
											<th>f1602</th>
											<th>f1603</th>
											<th>f1604</th>
											<th>f1605</th>
											<th>f1606</th>
											<th>f1607</th>
											<th>f1608</th>
											<th>f1609</th>
											<th>f1610</th>
											<th>f1611</th>
											<th>f1612</th>
											<th>f1613</th>
											<th>f1614</th>
											<th>f1701</th>
											<th>f1702b</th>
											<th>f1703</th>
											<th>f1704b</th>
											<th>f1705</th>
											<th>f1705a</th>
											<th>f1706</th>
											<th>f1706ba</th>
											<th>f1707</th>
											<th>f1708b</th>
											<th>f1709</th>
											<th>f1710b</th>
											<th>f1711</th>
											<th>f1711a</th>
											<th>f1712b</th>
											<th>f1712a</th>
											<th>f1713</th>
											<th>f1714b</th>
											<th>f1715</th>
											<th>f1716b</th>
											<th>f1717</th>
											<th>f1718b</th>
											<th>f1719</th>
											<th>f1720b</th>
											<th>f1721</th>
											<th>f1722b</th>
											<th>f1723</th>
											<th>f1724b</th>
											<th>f1725</th>
											<th>f1726b</th>
											<th>f1727</th>
											<th>f1728b</th>
											<th>f1729</th>
											<th>f1730b</th>
											<th>f1731</th>
											<th>f1732b</th>
											<th>f1733</th>
											<th>f1734b</th>
											<th>f1735</th>
											<th>f1736b</th>
											<th>f1737</th>
											<th>f1737a</th>
											<th>f1738</th>
											<th>f1738ba</th>
											<th>f1739</th>
											<th>f1740b</th>
											<th>f1741</th>
											<th>f1742b</th>
											<th>f1743</th>
											<th>f1744b</th>
											<th>f1745</th>
											<th>f1746b</th>
											<th>f1747</th>
											<th>f1748b</th>
											<th>f1749</th>
											<th>f1750b</th>
											<th>f1751</th>
											<th>f1752b</th>
											<th>f1753</th>
											<th>f1754b</th>
											<th>akreditasi</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
									
									<?php
									//ambil database dari tabel
									$sql = "SELECT * FROM tbl_questionnaire";
									$hasil = $mysqli->query($sql) or die ($mysqli->error._LINE_);
									while($row=mysqli_fetch_array($hasil)){
										echo "<tr>";
										echo "<td>071050</td>";
										echo "<td>".$row['prody']."</td>";
										echo "<td>".$row['npm']."</td>";
										echo "<td>".$row['name']."</td>";
										echo "<td>".$row['phone']."</td>";
										echo "<td>".$row['email']."</td>";
										echo "<td>".$row['graduation_year']."</td>";
										echo "<td>".$row['f21']."</td>";
										echo "<td>".$row['f22']."</td>";
										echo "<td>".$row['f23']."</td>";
										echo "<td>".$row['f24']."</td>";
										echo "<td>".$row['f25']."</td>";
										echo "<td>".$row['f26']."</td>";
										echo "<td>".$row['f27']."</td>";
										echo "<td>".$row['f301']."</td>";
										echo "<td>".$row['f302']."</td>";
										echo "<td>".$row['f303']."</td>";
										echo "<td>".$row['f401']."</td>";
										echo "<td>".$row['f402']."</td>";
										echo "<td>".$row['f403']."</td>";
										echo "<td>".$row['f404']."</td>";
										echo "<td>".$row['f405']."</td>";
										echo "<td>".$row['f406']."</td>";
										echo "<td>".$row['f407']."</td>";
										echo "<td>".$row['f408']."</td>";
										echo "<td>".$row['f409']."</td>";
										echo "<td>".$row['f410']."</td>";
										echo "<td>".$row['f411']."</td>";
										echo "<td>".$row['f412']."</td>";
										echo "<td>".$row['f413']."</td>";
										echo "<td>".$row['f414']."</td>";
										echo "<td>".$row['f415']."</td>";
										echo "<td>".$row['f416']."</td>";
										echo "<td>".$row['f6']."</td>";
										echo "<td>".$row['f501']."</td>";
										echo "<td>".$row['f502']."</td>";
										echo "<td>".$row['f503']."</td>";
										echo "<td>".$row['f7']."</td>";
										echo "<td>".$row['f7a']."</td>";
										echo "<td>".$row['f8']."</td>";
										echo "<td>".$row['f901']."</td>";
										echo "<td>".$row['f902']."</td>";
										echo "<td>".$row['f903']."</td>";
										echo "<td>".$row['f904']."</td>";
										echo "<td>".$row['f905']."</td>";
										echo "<td>".$row['f906']."</td>";
										echo "<td>".$row['f1001']."</td>";
										echo "<td>".$row['f1002']."</td>";
										echo "<td>".$row['f1101']."</td>";
										echo "<td>".$row['f1102']."</td>";
										echo "<td>".$row['f1201']."</td>";
										echo "<td>".$row['f1202']."</td>";
										echo "<td>".$row['f1301']."</td>";
										echo "<td>".$row['f1302']."</td>";
										echo "<td>".$row['f1303']."</td>";
										echo "<td>".$row['f14']."</td>";
										echo "<td>".$row['f15']."</td>";
										echo "<td>".$row['f1601']."</td>";
										echo "<td>".$row['f1602']."</td>";
										echo "<td>".$row['f1603']."</td>";
										echo "<td>".$row['f1604']."</td>";
										echo "<td>".$row['f1605']."</td>";
										echo "<td>".$row['f1606']."</td>";
										echo "<td>".$row['f1607']."</td>";
										echo "<td>".$row['f1608']."</td>";
										echo "<td>".$row['f1609']."</td>";
										echo "<td>".$row['f1610']."</td>";
										echo "<td>".$row['f1611']."</td>";
										echo "<td>".$row['f1612']."</td>";
										echo "<td>".$row['f1613']."</td>";
										echo "<td>".$row['f1614']."</td>";
										echo "<td>".$row['f1701']."</td>";
										echo "<td>".$row['f1702b']."</td>";
										echo "<td>".$row['f1703']."</td>";
										echo "<td>".$row['f1704b']."</td>";
										echo "<td>".$row['f1705']."</td>";
										echo "<td>".$row['f1705a']."</td>";
										echo "<td>".$row['f1706b']."</td>";
										echo "<td>".$row['f1706ba']."</td>";
										echo "<td>".$row['f1707']."</td>";
										echo "<td>".$row['f1708b']."</td>";
										echo "<td>".$row['f1709']."</td>";
										echo "<td>".$row['f1710b']."</td>";
										echo "<td>".$row['f1711']."</td>";
										echo "<td>".$row['f1711a']."</td>";
										echo "<td>".$row['f1712b']."</td>";
										echo "<td>".$row['f1712a']."</td>";
										echo "<td>".$row['f1713']."</td>";
										echo "<td>".$row['f1714b']."</td>";
										echo "<td>".$row['f1715']."</td>";
										echo "<td>".$row['f1716b']."</td>";
										echo "<td>".$row['f1717']."</td>";
										echo "<td>".$row['f1718b']."</td>";
										echo "<td>".$row['f1719']."</td>";
										echo "<td>".$row['f1720b']."</td>";
										echo "<td>".$row['f1721']."</td>";
										echo "<td>".$row['f1722b']."</td>";
										echo "<td>".$row['f1723']."</td>";
										echo "<td>".$row['f1724b']."</td>";
										echo "<td>".$row['f1725']."</td>";
										echo "<td>".$row['f1726b']."</td>";
										echo "<td>".$row['f1727']."</td>";
										echo "<td>".$row['f1728b']."</td>";
										echo "<td>".$row['f1729']."</td>";
										echo "<td>".$row['f1730b']."</td>";
										echo "<td>".$row['f1731']."</td>";
										echo "<td>".$row['f1732b']."</td>";
										echo "<td>".$row['f1733']."</td>";
										echo "<td>".$row['f1734b']."</td>";
										echo "<td>".$row['f1735']."</td>";
										echo "<td>".$row['f1736b']."</td>";
										echo "<td>".$row['f1737']."</td>";
										echo "<td>".$row['f1737a']."</td>";
										echo "<td>".$row['f1738b']."</td>";
										echo "<td>".$row['f1738ba']."</td>";
										echo "<td>".$row['f1739']."</td>";
										echo "<td>".$row['f1740b']."</td>";
										echo "<td>".$row['f1731']."</td>";
										echo "<td>".$row['f1742b']."</td>";
										echo "<td>".$row['f1743']."</td>";
										echo "<td>".$row['f1744b']."</td>";
										echo "<td>".$row['f1745']."</td>";
										echo "<td>".$row['f1746b']."</td>";
										echo "<td>".$row['f1747']."</td>";
										echo "<td>".$row['f1748b']."</td>";
										echo "<td>".$row['f1749']."</td>";
										echo "<td>".$row['f1750b']."</td>";
										echo "<td>".$row['f1751']."</td>";
										echo "<td>".$row['f1752b']."</td>";
										echo "<td>".$row['f1753']."</td>";
										echo "<td>".$row['f1754b']."</td>";
										echo "<td>".$row['akreditasi']."</td>";
										echo "</tr>";
									
									
									}
									?>
										
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Exportable Table -->
        </div>
    </section>

    <!-- Jquery Core Js -->
    <script src="../../plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="../../plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="../../plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="../../plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="../../plugins/node-waves/waves.js"></script>

    <!-- Jquery DataTable Plugin Js -->
    <script src="../../plugins/jquery-datatable/jquery.dataTables.js"></script>
    <script src="../../plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
    <script src="../../plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>

    <!-- Custom Js -->
    <script src="../../js/admin.js"></script>
    <script src="../../js/pages/tables/jquery-datatable.js"></script>

    <!-- Demo Js -->
    <script src="../../js/demo.js"></script>
</body>

</html>
<?php
   }else{
	   header('location:../../cdc/index.php');//jika belum login jangan lanjut..
}
}else{
	header('location:../../cdc/index.php');//jika belum login jangan lanjut..
}
?>
