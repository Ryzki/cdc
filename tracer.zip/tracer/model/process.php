<?php
include 'set.php';
session_start();

//ambil dari url
$proces=$_GET['proses'];
//buat kondisi untuk lihat diproses pertanyaan keberapa
switch ($proces) {
			case 1:
			//cek validasi dulu
				if((empty($_GET['group1'])) or (empty($_GET['group2'])) or (empty($_GET['group3'])) or (empty($_GET['group4'])) or (empty($_GET['group5'])) or (empty($_GET['group6'])) or (empty($_GET['group7']))){
					header("location:../pages/ui/ask1.php?error");
					
				}else{
				$f21=$_GET['group1'];
				$f22=$_GET['group2'];
				$f23=$_GET['group3'];
				$f24=$_GET['group4'];
				$f25=$_GET['group5'];
				$f26=$_GET['group6'];
				$f27=$_GET['group7'];
				$npm=$_SESSION['npm'];
				$nama=$_SESSION['nama'];
				$email=$_SESSION['email'];
				$phone=$_SESSION['phone'];
				
				//ambil data dari tb_respondent
				$sql = "SELECT * FROM tbl_respondent WHERE npm='$npm'";
				$hasil = $mysqli->query($sql);
				while($row=mysqli_fetch_array($hasil)){
				$prody=$row['prody_code'];
				$graduation=$row['graduation_year'];
				}
				//update ke tabel
				$sql=$mysqli->query("insert into tbl_questionnaire(npm, name, prody, graduation_year, phone, email, f21, f22, f23, f24, f25, f26, f27) values('$npm','$nama','$prody','$graduation','$phone','$email','$f21','$f22','$f23','$f24','$f25','$f26','$f27')");
				if($sql){
					//update status
					$update=$mysqli->query("update tbl_respondent set status='1', remark='In Progres' where npm='$npm'");
					if($update){
							header("location:../pages/ui/ask2.php");
					}else{
							header("location:../index.php");
					}
			
				}else{
				header("location:../index.php");
				}
				}
				break;
			case 2:
				$rt=2;
				$rad=2;
			//cek validasi dulu
			if($_GET['rad']=="3"){
				$rt=0;
			}else if($_GET['input1']=="" and $_GET['input2']==""){
				header("location:../pages/ui/ask2.php?error");
				
			}else if(!empty($_GET['input1'])){
				if(!empty($_GET['input2'])){
					//echo "double";
					header("location:../pages/ui/ask2.php?double");
					}else{
				//MASALAH ADA DISINI	
						$rt=0;
					}
			}else if(!empty($_GET['input2'])){
				if(empty($_GET['input1'])){
						$rt=0;
				}
			}
			
			
			if($rt==0){
			//kondisi untuk proses delapan
			$rad=$_GET['rad'];
			//kondisi button 1 atau 2 yang dicentang, beri value 1 jika button 1, beri value 2 jika button 2
			if($rad==1){
				$f301=1;
			}else if($rad==2){
				$f301=2;
			}else if($rad==3){
				$f301=3;
			}
			//end
			$f302=$_GET['input1'];
			$f303=$_GET['input2'];
			$npm=$_SESSION['npm'];
			
					
			$update=$mysqli->query("update tbl_questionnaire set f301='$f301' , f302='$f302' , f303='$f303' where npm='$npm'");
			if($update){
					if($f301==3){
					//update status
					$update2=$mysqli->query("update tbl_respondent set status='7' where npm='$npm'");
					header("location:../pages/ui/ask8.php");
					}else{
							$update=$mysqli->query("update tbl_respondent set status='2' where npm='$npm'");
							header("location:../pages/ui/ask3.php");
					}
			
			}else{
			header("location:../index.php");
			}
			}
			break;
			case 3:
				//cek validasi dulu
				if((empty($_GET['f401'])) and (empty($_GET['f402'])) and  (empty($_GET['f403'])) and (empty($_GET['f404'])) and (empty($_GET['f405'])) and (empty($_GET['f406'])) and (empty($_GET['f407'])) and (empty($_GET['f408'])) and (empty($_GET['f409'])) and (empty($_GET['f410'])) and (empty($_GET['f411'])) and (empty($_GET['f412'])) and (empty($_GET['f413'])) and (empty($_GET['f414'])) and (empty($_GET['f415']))){
					header("location:../pages/ui/ask3.php?error");
				}else{
				$f401=$_GET['f401'];
				$f402=$_GET['f402'];
				$f403=$_GET['f403'];
				$f404=$_GET['f404'];
				$f405=$_GET['f405'];
				$f406=$_GET['f406'];
				$f407=$_GET['f407'];
				$f408=$_GET['f408'];
				$f409=$_GET['f409'];
				$f410=$_GET['f410'];
				$f411=$_GET['f411'];
				$f412=$_GET['f412'];
				$f413=$_GET['f413'];
				$f414=$_GET['f414'];
				$f415=$_GET['f415'];
				$f416=$_GET['input'];
				$npm=$_SESSION['npm'];
				//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set f401='$f401' , f402='$f402' , f403='$f403' , f404='$f404' , f405='$f405' , f406='$f406' , f407='$f407' , f408='$f408' , f409='$f409' , f410='$f410' , f411='$f411' , f412='$f412' , f413='$f413' , f414='$f414' , f415='$f415' , f416='$f416' where npm='$npm'");
				$status=$mysqli->query("update tbl_respondent set status='3' where npm='$npm'");
				if($update and $status){
					header("location:../pages/ui/ask4.php");
				}else{
					header("location:../index.php");
				}
				}
				break;
			case 4:
				$rt=1;
			//cek validasi dulu
			if($_GET['input1']=="" and $_GET['input2']==""){
				header("location:../pages/ui/ask4.php?error");
				//echo "Kosng semua harus ada yang diisi";
			}else if(!empty($_GET['input1'])){
				if(!empty($_GET['input2'])){
					//echo "double";
					header("location:../pages/ui/ask4.php?double");
					}else{
				//MASALAH ADA DISINI	
						$rt=0;
					}
			}else if(!empty($_GET['input2'])){
				if(empty($_GET['input1'])){
						$rt=0;
				}
			}
			
			if($rt==0){
			//kondisi untuk proses pertama
			$rad=$_GET['rad'];
			//kondisi button 1 atau 2 yang dicentang, beri value 1 jika button 1, beri value 2 jika button 2
			if($rad==1){
				$f501=1;
			}else{
				$f501=2;
			}
			//end
			$f502=$_GET['input1'];
			$f503=$_GET['input2'];
			$npm=$_SESSION['npm'];
						
			//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set f501='$f501', f502='$f502', f503='$f503' where npm='$npm'");
				$status=$mysqli->query("update tbl_respondent set status='4' where npm='$npm'");
				if($update and $status){
					header("location:../pages/ui/ask5.php");
				}else{
					header("location:../index.php");
				}
				
			}	
			break;
			case 5:
				$f6=$_GET['f6'];
				$npm=$_SESSION['npm'];
				//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set f6='$f6' where npm='$npm'");
				$status=$mysqli->query("update tbl_respondent set status='5' where npm='$npm'");
				if($update and $status){
					header("location:../pages/ui/ask6.php");
				}else{
					header("location:../index.php");
				}
				break;
			case 6:
				
				$f7=$_GET['f7'];
				$npm=$_SESSION['npm'];
				//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set f7='$f7' where npm='$npm'");
				$status=$mysqli->query("update tbl_respondent set status='6' where npm='$npm'");
				if($update and $status){
					header("location:../pages/ui/ask7.php");
				}else{
					header("location:../index.php");
				}
				break;
			case 7:
				$f7a=$_GET['f7a'];
				$npm=$_SESSION['npm'];
				//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set f7a='$f7a' where npm='$npm'");
				$status=$mysqli->query("update tbl_respondent set status='7' where npm='$npm'");
				if($update and $status){
					header("location:../pages/ui/ask8.php");
				}else{
					header("location:../index.php");
				}
				break;
			case 8:
				//cek validasi dulu
				if(empty($_GET['group5'])){
					header("location:../pages/ui/ask8.php?error");
				}else{
				$f8=$_GET['group5'];
				$npm=$_SESSION['npm'];
				//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set f8='$f8' where npm='$npm'");
				//$status=$mysqli->query("update tbl_respondent set status='8' where npm='$npm'");
				if($update){
					if($f8==1){
					//update status
					$update2=$mysqli->query("update tbl_respondent set status='10' where npm='$npm'");
					header("location:../pages/ui/ask11.php");
					}else{
							$update=$mysqli->query("update tbl_respondent set status='8' where npm='$npm'");
							header("location:../pages/ui/ask9.php");
					}
					
				}else{
					header("location:../index.php");
				}
				}
				break;
			case 9:
				//cek validasi dulu
				if((empty($_GET['f901'])) and (empty($_GET['f902'])) and  (empty($_GET['f903'])) and (empty($_GET['f904'])) and (empty($_GET['f905'])) and (empty($_GET['f906']))){
					header("location:../pages/ui/ask9.php?error");
				}else{
				$f901=$_GET['f901'];
				$f902=$_GET['f902'];
				$f903=$_GET['f903'];
				$f904=$_GET['f904'];
				$f905=$_GET['f905'];
				$f906=$_GET['input'];
				$npm=$_SESSION['npm'];
				//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set f901='$f901' , f902='$f902' , f903='$f903' , f904='$f904' , f905='$f905' , f906='$f906' where npm='$npm'");
				$status=$mysqli->query("update tbl_respondent set status='9' where npm='$npm'");
				if($update and $status){
					header("location:../pages/ui/ask10.php");
				}else{
					header("location:../index.php");
				}
				}
				break;
			case 10:
				//cek validasi dulu
				if(empty($_GET['group5'])){
					header("location:../pages/ui/ask10.php?error");
				}else{
				$f1001=$_GET['group5'];
				$f1002=$_GET['input'];
				$npm=$_SESSION['npm'];
				//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set f1001='$f1001' , f1002='$f1002' where npm='$npm'");
				$status=$mysqli->query("update tbl_respondent set status='16' where npm='$npm'");
				if($update and $status){
					header("location:../pages/ui/ask17.php");
				}else{
					header("location:../index.php");
				}
				}
				break;
			case 11:
				//cek validasi dulu
				if(empty($_GET['group5'])){
					header("location:../pages/ui/ask11.php?error");
				}else{
				$f1101=$_GET['group5'];
				$f1102=$_GET['input'];
				$npm=$_SESSION['npm'];
				//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set f1101='$f1101', f1102='$f1102' where npm='$npm'");
				$status=$mysqli->query("update tbl_respondent set status='11' where npm='$npm'");
				if($update and $status){
					header("location:../pages/ui/ask12.php");
				}else{
					header("location:../index.php");
				}
				}
				break;
			case 12:
				//cek validasi dulu
				if(empty($_GET['group5'])){
					header("location:../pages/ui/ask12.php?error");
				}else{
				$f1201=$_GET['group5'];
				$f1202=$_GET['input'];
				$npm=$_SESSION['npm'];
				//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set f1201='$f1201' , f1202='$f1202' where npm='$npm'");
				$status=$mysqli->query("update tbl_respondent set status='12' where npm='$npm'");
				if($update and $status){
					header("location:../pages/ui/ask13.php");
				}else{
					header("location:../index.php");
				}
				}
				break;
			case 13:
				$f1301=$_GET['f1301'];
				$f1302=$_GET['f1302'];
				$f1303=$_GET['f1303'];
				$npm=$_SESSION['npm'];
				//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set f1301='$f1301' , f1302='$f1302' , f1303='$f1303' where npm='$npm'");
				$status=$mysqli->query("update tbl_respondent set status='13' where npm='$npm'");
				if($update and $status){
					header("location:../pages/ui/ask14.php");
				}else{
					header("location:../index.php");
				}
				
				break;
			case 14:
				//cek validasi dulu
				if(empty($_GET['group5'])){
					header("location:../pages/ui/ask14.php?error");
				}else{
				$f14=$_GET['group5'];
				$npm=$_SESSION['npm'];
				//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set f14='$f14' where npm='$npm'");
				$status=$mysqli->query("update tbl_respondent set status='14' where npm='$npm'");
				if($update and $status){
					header("location:../pages/ui/ask15.php");
				}else{
					header("location:../index.php");
				}
				}
				break;
			case 15:
				//cek validasi dulu
				if(empty($_GET['group5'])){
					header("location:../pages/ui/ask15.php?error");
				}else{
				$f15=$_GET['group5'];
				$npm=$_SESSION['npm'];
				//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set f15='$f15' where npm='$npm'");
				$status=$mysqli->query("update tbl_respondent set status='15' where npm='$npm'");
				if($update and $status){
					header("location:../pages/ui/ask16.php");
				}else{
					header("location:../index.php");
				}
				}
				break;
			case 16:
				//cek validasi dulu
				if((empty($_GET['f1601'])) and (empty($_GET['f1602'])) and  (empty($_GET['f1603'])) and (empty($_GET['f1604'])) and (empty($_GET['f1605'])) and (empty($_GET['f1606'])) and (empty($_GET['f1607'])) and (empty($_GET['f1608'])) and (empty($_GET['f1609'])) and (empty($_GET['f1610'])) and (empty($_GET['f1611'])) and (empty($_GET['f1612'])) and (empty($_GET['f1613'])) and (empty($_GET['f1614']))){
					header("location:../pages/ui/ask16.php?error");
				}else{
				$f1601=$_GET['f1601'];
				$f1602=$_GET['f1602'];
				$f1603=$_GET['f1603'];
				$f1604=$_GET['f1604'];
				$f1605=$_GET['f1605'];
				$f1606=$_GET['f1606'];
				$f1607=$_GET['f1607'];
				$f1608=$_GET['f1608'];
				$f1609=$_GET['f1609'];
				$f1610=$_GET['f1610'];
				$f1611=$_GET['f1611'];
				$f1612=$_GET['f1612'];
				$f1613=$_GET['f1613'];	
				$f1614=$_GET['input'];
				$npm=$_SESSION['npm'];
				//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set f1601='$f1601' , f1602='$f1602' , f1603='$f1603' , f1604='$f1604' , f1605='$f1605' , f1606='$f1606' , f1607='$f1607' , f1608='$f1608' , f1609='$f1609' , f1610='$f1610' , f1611='$f1611' , f1612='$f1612' , f1613='$f1613' , f1614='$f1614' where npm='$npm'");
				$status=$mysqli->query("update tbl_respondent set status='16' where npm='$npm'");
				if($update and $status){
					header("location:../pages/ui/ask17.php");
				}else{
					header("location:../index.php");
				}
				}
				break;
			case 17:
				//cek validasi dulu
				if((empty($_GET['group1'])) or (empty($_GET['group2'])) or (empty($_GET['group3'])) or (empty($_GET['group4'])) or (empty($_GET['group5'])) or (empty($_GET['group6'])) or (empty($_GET['group7'])) or (empty($_GET['group8'])) or (empty($_GET['group9'])) or (empty($_GET['group10'])) or (empty($_GET['group11'])) or (empty($_GET['group12'])) or (empty($_GET['group13'])) or (empty($_GET['group14'])) or (empty($_GET['group15'])) or (empty($_GET['group16'])) or (empty($_GET['group17'])) or (empty($_GET['group18'])) or (empty($_GET['group19'])) or (empty($_GET['group20'])) or (empty($_GET['group21'])) or (empty($_GET['group22'])) or(empty($_GET['group23'])) or (empty($_GET['group24'])) or (empty($_GET['group25'])) or (empty($_GET['group26'])) or (empty($_GET['group27'])) or (empty($_GET['group28'])) or (empty($_GET['group29']))){
					header("location:../pages/ui/ask17.php?error");
				}else{
				$f1701=$_GET['group1'];
				$f1703=$_GET['group2'];
				$f1705=$_GET['group3'];
				$f1705a=$_GET['group4'];
				$f1707=$_GET['group5'];
				$f1709=$_GET['group6'];
				$f1711=$_GET['group7'];
				$f1713=$_GET['group8'];
				$f1715=$_GET['group9'];
				$f1717=$_GET['group10'];
				$f1719=$_GET['group11'];
				$f1721=$_GET['group12'];
				$f1723=$_GET['group13'];
				$f1725=$_GET['group14'];
				$f1727=$_GET['group15'];
				$f1729=$_GET['group16'];
				$f1731=$_GET['group17'];
				$f1733=$_GET['group18'];
				$f1735=$_GET['group19'];
				$f1737=$_GET['group20'];
				$f1737a=$_GET['group21'];
				$f1739=$_GET['group22'];
				$f1741=$_GET['group23'];
				$f1743=$_GET['group24'];
				$f1745=$_GET['group25'];
				$f1747=$_GET['group26'];
				$f1749=$_GET['group27'];
				$f1751=$_GET['group28'];
				$f1753=$_GET['group29'];
				$npm=$_SESSION['npm'];
				//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set f1701='$f1701' , f1703='$f1703' , f1705='$f1705' , f1705a='$f1705a' , f1707='$f1707' , f1709='$f1709' , f1711='$f1711' , f1713='$f1713' , f1715='$f1715' , f1717='$f1717' , f1719='$f1719' , f1721='$f1721' , f1723='$f1723' , f1725='$f1725' , f1727='$f1727' , f1729='$f1729' , f1731='$f1731' , f1733='$f1733' , f1735='$f1735' , f1737='$f1737' , f1737a='$f1737a' , f1739='$f1739' , f1741='$f1741' , f1743='$f1743' , f1745='$f1745' , f1747='$f1747' , f1749='$f1749' , f1751='$f1751' , f1753='$f1753' where npm='$npm'");
				$status=$mysqli->query("update tbl_respondent set status='17' where npm='$npm'");
				if($update and $status){
					header("location:../pages/ui/ask18.php");
				}else{
					header("location:../index.php");
				}
				}
				break;
			case 18:
				//cek validasi dulu
				if((empty($_GET['group1'])) or (empty($_GET['group2'])) or (empty($_GET['group3'])) or (empty($_GET['group4'])) or (empty($_GET['group5'])) or (empty($_GET['group6'])) or (empty($_GET['group7'])) or (empty($_GET['group8'])) or (empty($_GET['group9'])) or (empty($_GET['group10'])) or (empty($_GET['group11'])) or (empty($_GET['group12'])) or (empty($_GET['group13'])) or (empty($_GET['group14'])) or (empty($_GET['group15'])) or (empty($_GET['group16'])) or (empty($_GET['group17'])) or (empty($_GET['group18'])) or (empty($_GET['group19'])) or (empty($_GET['group20'])) or (empty($_GET['group21'])) or (empty($_GET['group22'])) or(empty($_GET['group23'])) or (empty($_GET['group24'])) or (empty($_GET['group25'])) or (empty($_GET['group26'])) or (empty($_GET['group27'])) or (empty($_GET['group28'])) or (empty($_GET['group29']))){
					header("location:../pages/ui/ask18.php?error");
				}else{
				$f1702b=$_GET['group1'];
				$f1704b=$_GET['group2'];
				$f1706b=$_GET['group3'];
				$f1706ba=$_GET['group4'];
				$f1708b=$_GET['group5'];
				$f1710b=$_GET['group6'];
				$f1712b=$_GET['group7'];
				$f1714b=$_GET['group8'];
				$f1716b=$_GET['group9'];
				$f1718b=$_GET['group10'];
				$f1720b=$_GET['group11'];
				$f1722b=$_GET['group12'];
				$f1724b=$_GET['group13'];
				$f1726b=$_GET['group14'];
				$f1728b=$_GET['group15'];
				$f1730b=$_GET['group16'];
				$f1732b=$_GET['group17'];
				$f1734b=$_GET['group18'];
				$f1736b=$_GET['group19'];
				$f1738b=$_GET['group20'];
				$f1738ba=$_GET['group21'];
				$f1740b=$_GET['group22'];
				$f1742b=$_GET['group23'];
				$f1744b=$_GET['group24'];
				$f1746b=$_GET['group25'];
				$f1748b=$_GET['group26'];
				$f1750b=$_GET['group27'];
				$f1752b=$_GET['group28'];
				$f1754b=$_GET['group29'];
				$npm=$_SESSION['npm'];
				//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set f1702b='$f1702b' , f1704b='$f1704b' , f1706b='$f1706b' , f1706ba='$f1706ba' , f1708b='$f1708b' , f1710b='$f1710b' , f1712b='$f1712b' , f1714b='$f1714b' , f1716b='$f1716b' , f1718b='$f1718b' , f1720b='$f1720b' , f1722b='$f1722b' , f1724b='$f1724b' , f1726b='$f1726b' , f1728b='$f1728b' , f1730b='$f1730b' , f1732b='$f1732b' , f1734b='$f1734b' , f1736b='$f1736b' , f1738b='$f1738b' , f1738ba='$f1738ba' , f1740b='$f1740b' , f1742b='$f1742b' , f1744b='$f1744b' , f1746b='$f1746b' , f1748b='$f1748b' , f1750b='$f1750b' , f1752b='$f1752b' , f1754b='$f1754b' where npm='$npm'");
				$status=$mysqli->query("update tbl_respondent set status='18' where npm='$npm'");
				if($update and $status){
					header("location:../pages/ui/ask19.php");
				}else{
					header("location:../index.php");
				}
				}
				break;
			case 19:
				//cek validasi dulu
				if(empty($_GET['group5'])){
					header("location:../pages/ui/ask19.php?error");
				}else{
				$f15=$_GET['group5'];
				$npm=$_SESSION['npm'];
				//update ke tabel
				$update=$mysqli->query("update tbl_questionnaire set akreditasi='$f15' where npm='$npm'");
				$status=$mysqli->query("update tbl_respondent set status='19' , remark='Complete' where npm='$npm'");
				if($update and $status){
					header("location:../pages/ui/thanks.php");
				}else{
					header("location:../index.php");
				}
				}
				break;
			case 20:
				header("location:../pages/ui/thanks.php");
				break;
				
			
			default:
				header("location:../pages/examples/404.html");
				break;
		}


?>