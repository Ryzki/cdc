﻿<!DOCTYPE html>
<html>

<?php

session_start();
include '../../model/set.php';
//cek apakah sudah login
if(empty($_SESSION['npm'])){
   header('location:../../index.php');//jika belum login jangan lanjut..
}
?>
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Unikama | Tracer Study</title>
    <!-- Favicon-->
    <link rel="icon" href="../../favicon.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="../../plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="../../plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="../../plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="../../css/style.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="../../css/themes/all-themes.css" rel="stylesheet" />
	
	
	
</head>

<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="START TYPING...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
    <nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="javascript:void(0);" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="javascript:void(0);" class="bars"></a>
                <a class="navbar-brand" href="../../index.php">Unikama - Tracer Study</a>
            </div>
            
        </div>
    </nav>
    <!-- #Top Bar -->
    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="user-info">
                <div class="image">
                    <img src="../../images/logo.png" width="48" height="48" alt="User" />
                </div>
                <div class="info-container">
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['nama'] ?></div>
                    <div class="email"><?php echo $_SESSION['email'] ?></div>
                    
                </div>
            </div>
            <!-- #User Info -->
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    
                    <li>
                        <a href="../../index.php">
                            <i class="material-icons">home</i>
                            <span>Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="../../model/log.php?submit=out">
                            <i class="material-icons">arrow_back</i>
                            <span>Keluar</span>
                        </a>
                    </li>
                </ul>
            </div>
            <!-- #Menu -->
            <!-- Footer -->
            <div class="legal">
                <div class="copyright">
                    &copy; 2019 <a href="javascript:void(0);">Blackantcreative</a>
                </div>
            </div>
            <!-- #Footer -->
        </aside>
        <!-- #END# Left Sidebar -->
        <!-- Right Sidebar -->
        
        <!-- #END# Right Sidebar -->
    

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2></h2>
            </div>

            <!-- Basic Alerts -->
            <div class="row clearfix">
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box-4 hover-zoom-effect">
                        <div class="icon">
                            <i class="material-icons col-pink">question_answer</i>
                        </div>
                        <div class="content">
                            <div class="text">QUESTIONNAIRE</div>
                            <div class="number">17 of 18</div>
                        </div>
                    </div>

                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
						
                        
                        <div class="body">
                            
                            <div class="alert alert-info">
                                <strong>Question</strong>
                            </div>
							<!-- Menampilkan pesan error -->
							<?php if(isset($_GET["error"])) { ?>
							<div class="alert alert-warning alert-dismissible" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                Data tidak boleh kosong
                            </div>
							<?php } ?>
							<form id="sign_up" method="get" action="../../model/process.php">
								<div class="msg">
								Pada saat lulus, pada tingkat mana kompetensi dibawah ini yang anda kuasai ? (1-2 merupakan skor rendah, 3 medium, 4-5 merupakan skor tinggi)
								</div><br/>
								<table>
								<tr style="font-weight:bold;">
									<td colspan="2">Rendah</td><td></td><td colspan="2">Tinggi</td>
								</tr>
								<tr style="text-align:center;border-top:solid 1px #000;border-bottom: solid 1px #000;height:30px;font-weight:bold;">
									<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td></td><td></td>
								</tr>
								<tr id="group1" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group1" type="radio" id="radio_31" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_31"></label></td>
                                <td><input name="group1" type="radio" id="radio_32" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_32"></label></td>
                                <td><input name="group1" type="radio" id="radio_33" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_33"></label></td>
                                <td><input name="group1" type="radio" id="radio_34" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_34"></label></td>
                                <td><input name="group1" type="radio" id="radio_35" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_35"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Pengetahuan di bidang atau disiplin ilmu anda</td>
								</tr>
								
								<tr id="group2" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group2" type="radio" id="radio_36" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_36"></label></td>
                                <td><input name="group2" type="radio" id="radio_37" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_37"></label></td>
                                <td><input name="group2" type="radio" id="radio_38" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_38"></label></td>
                                <td><input name="group2" type="radio" id="radio_39" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_39"></label></td>
                                <td><input name="group2" type="radio" id="radio_40" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_40"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Pengetahuan di luar bidang atau disiplin ilmu anda</td>
								</tr>
								
								<tr id="group3" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group3" type="radio" id="radio_41" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_41"></label></td>
                                <td><input name="group3" type="radio" id="radio_42" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_42"></label></td>
                                <td><input name="group3" type="radio" id="radio_43" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_43"></label></td>
                                <td><input name="group3" type="radio" id="radio_44" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_44"></label></td>
                                <td><input name="group3" type="radio" id="radio_45" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_45"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Pengetahuan umum</td>
								</tr>
								
								<tr id="group4" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group4" type="radio" id="radio_46" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_46"></label></td>
                                <td><input name="group4" type="radio" id="radio_47" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_47"></label></td>
                                <td><input name="group4" type="radio" id="radio_48" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_48"></label></td>
                                <td><input name="group4" type="radio" id="radio_49" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_49"></label></td>
                                <td><input name="group4" type="radio" id="radio_50" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_50"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Bahasa Inggris</td>
								</tr>
								
								<tr id="group5" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group5" type="radio" id="radio_51" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_51"></label></td>
                                <td><input name="group5" type="radio" id="radio_52" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_52"></label></td>
                                <td><input name="group5" type="radio" id="radio_53" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_53"></label></td>
                                <td><input name="group5" type="radio" id="radio_54" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_54"></label></td>
                                <td><input name="group5" type="radio" id="radio_55" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_55"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Ketrampilan internet</td>
								</tr>
								
								<tr id="group6" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group6" type="radio" id="radio_56" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_56"></label></td>
                                <td><input name="group6" type="radio" id="radio_57" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_57"></label></td>
                                <td><input name="group6" type="radio" id="radio_58" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_58"></label></td>
                                <td><input name="group6" type="radio" id="radio_59" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_59"></label></td>
                                <td><input name="group6" type="radio" id="radio_60" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_60"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Ketrampilan komputer</td>
								</tr>
								
								<tr id="group7" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group7" type="radio" id="radio_61" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_61"></label></td>
                                <td><input name="group7" type="radio" id="radio_62" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_62"></label></td>
                                <td><input name="group7" type="radio" id="radio_63" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_63"></label></td>
                                <td><input name="group7" type="radio" id="radio_64" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_64"></label></td>
                                <td><input name="group7" type="radio" id="radio_65" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_65"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Berpikir kritis</td>
								</tr>
								
								<tr id="group8" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group8" type="radio" id="radio_66" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_66"></label></td>
                                <td><input name="group8" type="radio" id="radio_67" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_67"></label></td>
                                <td><input name="group8" type="radio" id="radio_68" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_68"></label></td>
                                <td><input name="group8" type="radio" id="radio_69" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_69"></label></td>
                                <td><input name="group8" type="radio" id="radio_70" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_70"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Ketrampilan riset</td>
								</tr>
								
								<tr id="group9" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group9" type="radio" id="radio_71" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_71"></label></td>
                                <td><input name="group9" type="radio" id="radio_72" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_72"></label></td>
                                <td><input name="group9" type="radio" id="radio_73" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_73"></label></td>
                                <td><input name="group9" type="radio" id="radio_74" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_74"></label></td>
                                <td><input name="group9" type="radio" id="radio_75" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_75"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Kemampuan belajar</td>
								</tr>
								
								<tr id="group10" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group10" type="radio" id="radio_76" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_76"></label></td>
                                <td><input name="group10" type="radio" id="radio_77" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_77"></label></td>
                                <td><input name="group10" type="radio" id="radio_78" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_78"></label></td>
                                <td><input name="group10" type="radio" id="radio_79" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_79"></label></td>
                                <td><input name="group10" type="radio" id="radio_80" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_80"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Kemampuan berkomunikasi</td>
								</tr>
								
								<tr id="group11" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group11" type="radio" id="radio_81" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_81"></label></td>
                                <td><input name="group11" type="radio" id="radio_82" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_82"></label></td>
                                <td><input name="group11" type="radio" id="radio_83" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_83"></label></td>
                                <td><input name="group11" type="radio" id="radio_84" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_84"></label></td>
                                <td><input name="group11" type="radio" id="radio_85" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_85"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Bekerja dibawah tekanan</td>
								</tr>
								
								<tr id="group12" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group12" type="radio" id="radio_86" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_86"></label></td>
                                <td><input name="group12" type="radio" id="radio_87" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_87"></label></td>
                                <td><input name="group12" type="radio" id="radio_88" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_88"></label></td>
                                <td><input name="group12" type="radio" id="radio_89" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_89"></label></td>
                                <td><input name="group12" type="radio" id="radio_90" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_90"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Manajemen waktu</td>
								</tr>
								
								<tr id="group13" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group13" type="radio" id="radio_91" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_91"></label></td>
                                <td><input name="group13" type="radio" id="radio_92" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_92"></label></td>
                                <td><input name="group13" type="radio" id="radio_93" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_93"></label></td>
                                <td><input name="group13" type="radio" id="radio_94" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_94"></label></td>
                                <td><input name="group13" type="radio" id="radio_95" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_95"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Bekerja secara mandiri</td>
								</tr>
								
								<tr id="group14" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group14" type="radio" id="radio_96" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_96"></label></td>
                                <td><input name="group14" type="radio" id="radio_97" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_97"></label></td>
                                <td><input name="group14" type="radio" id="radio_98" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_98"></label></td>
                                <td><input name="group14" type="radio" id="radio_99" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_99"></label></td>
                                <td><input name="group14" type="radio" id="radio_100" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_100"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Bekerja dalam tim/bekerjasama dengan orang lain</td>
								</tr>
								
								<tr id="group15" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group15" type="radio" id="radio_101" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_101"></label></td>
                                <td><input name="group15" type="radio" id="radio_102" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_102"></label></td>
                                <td><input name="group15" type="radio" id="radio_103" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_103"></label></td>
                                <td><input name="group15" type="radio" id="radio_104" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_104"></label></td>
                                <td><input name="group15" type="radio" id="radio_105" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_105"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Kemampuan dalam memecahkan masalah</td>
								</tr>
								
								<tr id="group16" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group16" type="radio" id="radio_106" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_106"></label></td>
                                <td><input name="group16" type="radio" id="radio_107" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_107"></label></td>
                                <td><input name="group16" type="radio" id="radio_108" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_108"></label></td>
                                <td><input name="group16" type="radio" id="radio_109" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_109"></label></td>
                                <td><input name="group16" type="radio" id="radio_110" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_110"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Negosiasi</td>
								</tr>
								
								<tr id="group17" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group17" type="radio" id="radio_111" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_111"></label></td>
                                <td><input name="group17" type="radio" id="radio_112" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_112"></label></td>
                                <td><input name="group17" type="radio" id="radio_113" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_113"></label></td>
                                <td><input name="group17" type="radio" id="radio_114" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_114"></label></td>
                                <td><input name="group17" type="radio" id="radio_115" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_115"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Kemampuan analisis</td>
								</tr>
								
								<tr id="group18" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group18" type="radio" id="radio_116" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_116"></label></td>
                                <td><input name="group18" type="radio" id="radio_117" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_117"></label></td>
                                <td><input name="group18" type="radio" id="radio_118" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_118"></label></td>
                                <td><input name="group18" type="radio" id="radio_119" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_119"></label></td>
                                <td><input name="group18" type="radio" id="radio_120" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_120"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Toleransi</td>
								</tr>
								
								<tr id="group19" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group19" type="radio" id="radio_121" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_121"></label></td>
                                <td><input name="group19" type="radio" id="radio_122" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_122"></label></td>
                                <td><input name="group19" type="radio" id="radio_123" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_123"></label></td>
                                <td><input name="group19" type="radio" id="radio_124" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_124"></label></td>
                                <td><input name="group19" type="radio" id="radio_125" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_125"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Kemampuan adaptasi</td>
								</tr>
								
								<tr id="group20" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group20" type="radio" id="radio_126" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_126"></label></td>
                                <td><input name="group20" type="radio" id="radio_127" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_127"></label></td>
                                <td><input name="group20" type="radio" id="radio_128" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_128"></label></td>
                                <td><input name="group20" type="radio" id="radio_129" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_129"></label></td>
                                <td><input name="group20" type="radio" id="radio_130" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_130"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Loyalitas</td>
								</tr>
								
								<tr id="group21" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group21" type="radio" id="radio_131" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_131"></label></td>
                                <td><input name="group21" type="radio" id="radio_132" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_132"></label></td>
                                <td><input name="group21" type="radio" id="radio_133" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_133"></label></td>
                                <td><input name="group21" type="radio" id="radio_134" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_134"></label></td>
                                <td><input name="group21" type="radio" id="radio_135" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_135"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Integritas</td>
								</tr>
								
								<tr id="group22" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group22" type="radio" id="radio_136" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_136"></label></td>
                                <td><input name="group22" type="radio" id="radio_137" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_137"></label></td>
                                <td><input name="group22" type="radio" id="radio_138" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_138"></label></td>
                                <td><input name="group22" type="radio" id="radio_139" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_139"></label></td>
                                <td><input name="group22" type="radio" id="radio_140" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_140"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Bekerja dengan orang yang berbeda budaya maupun latar belakang</td>
								</tr>
								
								<tr id="group23" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group23" type="radio" id="radio_141" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_141"></label></td>
                                <td><input name="group23" type="radio" id="radio_142" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_142"></label></td>
                                <td><input name="group23" type="radio" id="radio_143" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_143"></label></td>
                                <td><input name="group23" type="radio" id="radio_144" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_144"></label></td>
                                <td><input name="group23" type="radio" id="radio_145" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_145"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Kepemimpinan</td>
								</tr>
								
								<tr id="group24" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group24" type="radio" id="radio_146" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_146"></label></td>
                                <td><input name="group24" type="radio" id="radio_147" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_147"></label></td>
                                <td><input name="group24" type="radio" id="radio_148" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_148"></label></td>
                                <td><input name="group24" type="radio" id="radio_149" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_149"></label></td>
                                <td><input name="group24" type="radio" id="radio_150" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_150"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Kemampuan dalam memegang tanggung jawab</td>
								</tr>
								
								<tr id="group25" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group25" type="radio" id="radio_151" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_151"></label></td>
                                <td><input name="group25" type="radio" id="radio_152" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_152"></label></td>
                                <td><input name="group25" type="radio" id="radio_153" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_153"></label></td>
                                <td><input name="group25" type="radio" id="radio_154" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_154"></label></td>
                                <td><input name="group25" type="radio" id="radio_155" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_155"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Inisiatif</td>
								</tr>
								
								<tr id="group26" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group26" type="radio" id="radio_156" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_156"></label></td>
                                <td><input name="group26" type="radio" id="radio_157" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_157"></label></td>
                                <td><input name="group26" type="radio" id="radio_158" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_158"></label></td>
                                <td><input name="group26" type="radio" id="radio_159" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_159"></label></td>
                                <td><input name="group26" type="radio" id="radio_160" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_160"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Manajemen proyek/program</td>
								</tr>
								
								<tr id="group27" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group27" type="radio" id="radio_161" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_161"></label></td>
                                <td><input name="group27" type="radio" id="radio_162" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_162"></label></td>
                                <td><input name="group27" type="radio" id="radio_163" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_163"></label></td>
                                <td><input name="group27" type="radio" id="radio_164" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_164"></label></td>
                                <td><input name="group27" type="radio" id="radio_165" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_165"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Kemampuan untuk memresentasikan ide/produk/laporan</td>
								</tr>
								
								<tr id="group28" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group28" type="radio" id="radio_166" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_166"></label></td>
                                <td><input name="group28" type="radio" id="radio_167" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_167"></label></td>
                                <td><input name="group28" type="radio" id="radio_168" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_168"></label></td>
                                <td><input name="group28" type="radio" id="radio_169" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_169"></label></td>
                                <td><input name="group28" type="radio" id="radio_170" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_170"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Kemampuan dalam menulis laporan, memo dan dokumen</td>
								</tr>
								
								<tr id="group29" style="border-bottom:dashed 1px gray;">
								<!--<div class="input-group">-->
								<!--<div class="demo-radio-button">-->
                                <td><input name="group29" type="radio" id="radio_171" value="1" class="with-gap radio-col-pink" />
                                <label for="radio_171"></label></td>
                                <td><input name="group29" type="radio" id="radio_172" value="2" class="with-gap radio-col-purple" />
                                <label for="radio_172"></label></td>
                                <td><input name="group29" type="radio" id="radio_173" value="3" class="with-gap radio-col-deep-purple" />
                                <label for="radio_173"></label></td>
                                <td><input name="group29" type="radio" id="radio_174" value="4" class="with-gap radio-col-indigo" />
                                <label for="radio_174"></label></td>
                                <td><input name="group29" type="radio" id="radio_175" value="5" class="with-gap radio-col-blue" />
                                <label for="radio_175"></label></td>
								<!--</div>-->	
								<!--</div>-->
								<td></td>
								<td>Kemampuan untuk terus belajar sepanjang hayat</td>
								</tr>
								</table>
								<br/><br/>
								<button class="btn btn-block btn-lg bg-pink waves-effect" type="submit" name="proses" value="17">Selanjutnya</button>

								<div class="row m-t-20 m-b--5 align-center">
									
								</div>
							</form>
							<!-- tambahkan jquery-->
	
							<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
							<script type="text/javascript">
							$(function(){
							$(":radio.rad").click(function(){
							$("#form1").hide()
							if($(this).val() == "1"){
							$("#form1").show();
							}
							});
							});
							</script>
                            
                        </div>
						
                    </div>
                </div>
            </div>
            <!-- #END# Basic Alerts -->
           
           
            
        </div>
    </section>

    <!-- Jquery Core Js -->
    <script src="../../plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="../../plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="../../plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="../../plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="../../plugins/node-waves/waves.js"></script>

    <!-- Custom Js -->
    <script src="../../js/admin.js"></script>

    <!-- Demo Js -->
    <script src="../../js/demo.js"></script>
</body>

</html>
