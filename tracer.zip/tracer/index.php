<html>
<head>
	<link href="css/bootstrap.css" rel="stylesheet" media="screen">
	<link href="css/bootstrap-responsive.css" rel="stylesheet">
	<script src="js/jquery.js"></script> 
	<script src="js/bootstrap.js"></script> 
	</head>
<body>

<?php
session_start();
include 'model/set.php';
//cek apakah user sudah melakukan login sebelumnya 

if(empty($_SESSION['npm'])){
		header("location:pages/examples/sign-in.php");
	}
	
else if(!empty($_SESSION['npm'])){
		$npm = $_SESSION['npm'];
		//ambil status
		$sql = "SELECT * FROM tbl_respondent where npm='$npm'";
		$hasil = $mysqli->query($sql);
		while($row=mysqli_fetch_array($hasil)){
			$status=$row['status'];
		}
		//buat kondisi
		switch ($status) {
			case 0:
				header("location:pages/ui/sambutan.php");
				break;
			case 1:
				header("location:pages/ui/ask2.php");
				break;
			case 2:
				header("location:pages/ui/ask3.php");
				break;
			case 3:
				header("location:pages/ui/ask4.php");
				break;
			case 4:
				header("location:pages/ui/ask5.php");
				break;
			case 5:
				header("location:pages/ui/ask6.php");
				break;
			case 6:
				header("location:pages/ui/ask7.php");
				break;
			case 7:
				header("location:pages/ui/ask8.php");
				break;
			case 8:
				header("location:pages/ui/ask9.php");
				break;
			case 9:
				header("location:pages/ui/ask10.php");
				break;
			case 10:
				header("location:pages/ui/ask11.php");
				break;
			case 11:
				header("location:pages/ui/ask12.php");
				break;
			case 12:
				header("location:pages/ui/ask13.php");
				break;
			case 13:
				header("location:pages/ui/ask14.php");
				break;
			case 14:
				header("location:pages/ui/ask15.php");
				break;
			case 15:
				header("location:pages/ui/ask16.php");
				break;
			case 16:
				header("location:pages/ui/ask17.php");
				break;
			case 17:
				header("location:pages/ui/ask18.php");
				break;
			case 18:
				header("location:pages/ui/ask19.php");
				break;
			case 19:
				header("location:pages/ui/close.php");
				break;	
			
			default:
				header("location:model/log.php?submit=out");
				break;
		}
		
}	
?>

