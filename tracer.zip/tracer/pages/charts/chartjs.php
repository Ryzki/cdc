﻿<!DOCTYPE html>
<html>
<?php

session_start();
include '../../model/set.php';


if(isset($_SESSION['userid'])){
	if(isset($_SESSION['psw'])){
	//header('location:../../cdc/index.php');//jika belum login jangan lanjut..
	
?>
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Unikama | Tracer Study</title>
    <!-- Favicon-->
    <link rel="icon" href="../../favicon.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="../../plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="../../plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="../../plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="../../css/style.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="../../css/themes/all-themes.css" rel="stylesheet" />
</head>

<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="START TYPING...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
    <nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="javascript:void(0);" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="javascript:void(0);" class="bars"></a>
               <a class="navbar-brand" href="../../cdc/index.php">Unikama - Tracer Study</a>
            </div>
            
        </div>
    </nav>
    <!-- #Top Bar -->
    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="user-info">
                <div class="image">
                    <img src="../../images/logo.png" width="48" height="48" alt="User" />
                </div>
                <div class="info-container">
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Hello , <?php echo $_SESSION['userid'] ?></div>
                    
                    
                </div>
            </div>
            <!-- #User Info -->
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                   
                    <li>
                        <a href="../../cdc/index.php">
                            <i class="material-icons">home</i>
                            <span>Home</span>
                        </a>
                    </li>
					<li>
                        <a href="../../pages/forms/editors.php">
                            <i class="material-icons">school</i>
                            <span>Sambutan</span>
                        </a>
                    </li>
					<li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">import_contacts</i>
                            <span>Program Studi</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="../../pages/tables/ListProdi.php">Daftar Prodi</a>
                            </li>
                            <li>
                                <a href="../../pages/forms/AddProdi.php">Tambah Prodi</a>
                            </li>
                        </ul>
                    </li>
					<li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">group</i>
                            <span>Alumni</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="../../pages/tables/main.php">Status</a>
                            </li>
                            <li>
                                <a href="../../pages/tables/dkt.php">Dikti</a>
                            </li>
							<li>
                                <a href="../../pages/tables/AddAlumni.php">Tambah Alumni</a>
                            </li>
                        </ul>
                    </li>
					<li>
                        <a href="../../pages/forms/updl.php">
                            <i class="material-icons">unarchive</i>
                            <span>Upload data</span>
                        </a>
                    </li>
					<li>
                        <a href="../../pages/charts/chartjs.php">
                            <i class="material-icons">pie_chart</i>
                            <span>Grafik</span>
                        </a>
                    </li>
					
                    <li>
                        <a href="../../model/log.php?submit=outmember">
                            <i class="material-icons">input</i>
                            <span>Keluar</span>
                        </a>
                    </li>
                    
                </ul>
            </div>
            <!-- #Menu -->
            <!-- Footer -->
            
            <!-- #Footer -->
        </aside>
        <!-- #END# Left Sidebar -->
        <!-- Right Sidebar -->
        <aside id="rightsidebar" class="right-sidebar">
            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                <li role="presentation" class="active"><a href="#skins" data-toggle="tab">SKINS</a></li>
                <li role="presentation"><a href="#settings" data-toggle="tab">SETTINGS</a></li>
            </ul>
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane fade in active in active" id="skins">
                    <ul class="demo-choose-skin">
                        <li data-theme="red" class="active">
                            <div class="red"></div>
                            <span>Red</span>
                        </li>
                        <li data-theme="pink">
                            <div class="pink"></div>
                            <span>Pink</span>
                        </li>
                        <li data-theme="purple">
                            <div class="purple"></div>
                            <span>Purple</span>
                        </li>
                        <li data-theme="deep-purple">
                            <div class="deep-purple"></div>
                            <span>Deep Purple</span>
                        </li>
                        <li data-theme="indigo">
                            <div class="indigo"></div>
                            <span>Indigo</span>
                        </li>
                        <li data-theme="blue">
                            <div class="blue"></div>
                            <span>Blue</span>
                        </li>
                        <li data-theme="light-blue">
                            <div class="light-blue"></div>
                            <span>Light Blue</span>
                        </li>
                        <li data-theme="cyan">
                            <div class="cyan"></div>
                            <span>Cyan</span>
                        </li>
                        <li data-theme="teal">
                            <div class="teal"></div>
                            <span>Teal</span>
                        </li>
                        <li data-theme="green">
                            <div class="green"></div>
                            <span>Green</span>
                        </li>
                        <li data-theme="light-green">
                            <div class="light-green"></div>
                            <span>Light Green</span>
                        </li>
                        <li data-theme="lime">
                            <div class="lime"></div>
                            <span>Lime</span>
                        </li>
                        <li data-theme="yellow">
                            <div class="yellow"></div>
                            <span>Yellow</span>
                        </li>
                        <li data-theme="amber">
                            <div class="amber"></div>
                            <span>Amber</span>
                        </li>
                        <li data-theme="orange">
                            <div class="orange"></div>
                            <span>Orange</span>
                        </li>
                        <li data-theme="deep-orange">
                            <div class="deep-orange"></div>
                            <span>Deep Orange</span>
                        </li>
                        <li data-theme="brown">
                            <div class="brown"></div>
                            <span>Brown</span>
                        </li>
                        <li data-theme="grey">
                            <div class="grey"></div>
                            <span>Grey</span>
                        </li>
                        <li data-theme="blue-grey">
                            <div class="blue-grey"></div>
                            <span>Blue Grey</span>
                        </li>
                        <li data-theme="black">
                            <div class="black"></div>
                            <span>Black</span>
                        </li>
                    </ul>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="settings">
                    <div class="demo-settings">
                        <p>GENERAL SETTINGS</p>
                        <ul class="setting-list">
                            <li>
                                <span>Report Panel Usage</span>
                                <div class="switch">
                                    <label><input type="checkbox" checked><span class="lever"></span></label>
                                </div>
                            </li>
                            <li>
                                <span>Email Redirect</span>
                                <div class="switch">
                                    <label><input type="checkbox"><span class="lever"></span></label>
                                </div>
                            </li>
                        </ul>
                        <p>SYSTEM SETTINGS</p>
                        <ul class="setting-list">
                            <li>
                                <span>Notifications</span>
                                <div class="switch">
                                    <label><input type="checkbox" checked><span class="lever"></span></label>
                                </div>
                            </li>
                            <li>
                                <span>Auto Updates</span>
                                <div class="switch">
                                    <label><input type="checkbox" checked><span class="lever"></span></label>
                                </div>
                            </li>
                        </ul>
                        <p>ACCOUNT SETTINGS</p>
                        <ul class="setting-list">
                            <li>
                                <span>Offline</span>
                                <div class="switch">
                                    <label><input type="checkbox"><span class="lever"></span></label>
                                </div>
                            </li>
                            <li>
                                <span>Location Permission</span>
                                <div class="switch">
                                    <label><input type="checkbox" checked><span class="lever"></span></label>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </aside>
        <!-- #END# Right Sidebar -->
    </section>
	
    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
   			
            </div>
            <div class="row clearfix">
                <!-- Line Chart -->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>PERKEMBANGAN TRACER STUDY</h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                   
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <canvas id="pie_chart" height="150"></canvas>
                        </div>
                    </div>
                </div>
                <!-- #END# Line Chart -->
                <!-- Bar Chart -->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>PERKEMBANGAN TRACER STUDY PER PRODI</h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <canvas id="bar_chart" height="150"></canvas>
                        </div>
                    </div>
                </div>
                <!-- #END# Bar Chart -->
            </div>
			<div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                REPORT TRACER STUDY
							</h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="body table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>JUMLAH PESERTA</th>
										<th colspan="2">BELUM SURVEY</th>
										<th colspan="2">COMPLETE</th>
                                    </tr>
                                </thead>
                                <tbody>
									
								<?php
								
									//buat array
									$query1 = "SELECT remark, count(*) as total FROM tbl_respondent"; 
									$result1 = mysqli_query($mysqli, $query1);
									while($row = mysqli_fetch_array($result1))  { 
									$tot=$row['total'];
										}
									//belum survey
									$query2 = "SELECT remark, count(*) as total FROM tbl_respondent where remark<>'Complete'"; 
									$result2 = mysqli_query($mysqli, $query2);
									while($row = mysqli_fetch_array($result2))  { 
									$blm=$row['total'];
										}
									//belum survey
									$query3 = "SELECT remark, count(*) as total FROM tbl_respondent where remark='Complete'"; 
									$result3 = mysqli_query($mysqli, $query3);
									while($row = mysqli_fetch_array($result3))  { 
									$c=$row['total'];
										}
									//hitung persentase
									if($tot<>0){
									$v=round(($blm/$tot)*100,2)."%";
									$z=round(($c/$tot)*100,2)."%";
									}else{
										$v='0%';
										$z='0%';
									}
									
								echo "<tr>";
                                echo "<th scope='row'>#</th>";
                                echo "<td>".$tot."</td>";
								echo "<td>".$blm."</td>";
								echo "<td>".$v."</td>";
								echo "<td>".$c."</td>";
								echo "<td>".$z."</td>";
								echo "</tr>";
								
                                ?>
									
                                    
                                   
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
			<div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                JUMLAH PESERTA TRACER PER PRODI
							</h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="body table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>KODE</th>
                                        <th>PRODI</th>
                                        <th>PESERTA</th>
										<th colspan="2">BELUM SURVEY</th>
										<th colspan="2">COMPLETE</th>
                                    </tr>
                                </thead>
                                <tbody>
									
								<?php
								$r=1;
								$sql = "SELECT * FROM prodi order by id_prodi asc";
								$hasil = $mysqli->query($sql) or die ($mysqli->error._LINE_);								   
								while($row=mysqli_fetch_array($hasil)){
									$kode[$r]=$row['kode'];
									$prodi[$r]=$row['prodi'];
									//buat array
									$query1 = "SELECT remark, count(*) as total FROM tbl_respondent where prody_code='$kode[$r]'"; 
									$result1 = mysqli_query($mysqli, $query1);
									while($row = mysqli_fetch_array($result1))  { 
									$tot[$r]=$row['total'];
										}
									//belum survey
									$query2 = "SELECT remark, count(*) as total FROM tbl_respondent where prody_code='$kode[$r]' and remark<>'Complete'"; 
									$result2 = mysqli_query($mysqli, $query2);
									while($row = mysqli_fetch_array($result2))  { 
									$blm[$r]=$row['total'];
									if($tot[$r]==0){
										$a='0%';
									}else{
									$a=round(($blm[$r]/$tot[$r])*100,2)."%";
									}
										}
									//complete survey
									$query3 = "SELECT remark, count(*) as total FROM tbl_respondent where prody_code='$kode[$r]' and remark='Complete'"; 
									$result3 = mysqli_query($mysqli, $query3);
									while($row = mysqli_fetch_array($result3))  { 
									$com[$r]=$row['total'];
									if($tot[$r]==0){
										$b='0%';
									}else{
									$b=round(($com[$r]/$tot[$r])*100,2)."%";
									}
										}
								echo "<tr>";
                                echo "<th scope='row'>".$r."</th>";
                                echo "<td>".$kode[$r]."</td>";
								echo "<td>".$prodi[$r]."</td>";
								echo "<td>".$tot[$r]."</td>";
								echo "<td>".$blm[$r]."</td>";
								echo "<td>".$a."</td>";
								echo "<td>".$com[$r]."</td>";
								echo "<td>".$b."</td>";
								echo "</tr>";
								$r++;
								}
                                ?>
									
                                    
                                   
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            
        </div>
    </section>
	<?php
	//ambil data tracer untuk pie chart
	$query = "SELECT remark, count(*) as total FROM tbl_respondent where remark='Belum Survey'"; 
	$result = mysqli_query($mysqli, $query);
	  while($row = mysqli_fetch_array($result))  { 
                               $blm=$row['total'];
						  } 
	$query = "SELECT remark, count(*) as total FROM tbl_respondent where remark='In Progres'"; 
	$result = mysqli_query($mysqli, $query);
	  while($row = mysqli_fetch_array($result))  { 
                               $in=$row['total'];
						  }
	$query = "SELECT remark, count(*) as total FROM tbl_respondent where remark='Complete'"; 
	$result = mysqli_query($mysqli, $query);
	  while($row = mysqli_fetch_array($result))  { 
                               $compl=$row['total'];
						  } 
	//ambil data untuk bar chart
	$r=0;
	$sql = "SELECT * FROM prodi order by id_prodi asc";
	$hasil = $mysqli->query($sql) or die ($mysqli->error._LINE_);								   
	?>
    <!-- Jquery Core Js -->
    <script src="../../plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="../../plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="../../plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="../../plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="../../plugins/node-waves/waves.js"></script>

    <!-- Chart Plugins Js -->
    <script src="../../plugins/chartjs/Chart.bundle.js"></script>

    <!-- Custom Js -->
    <script src="../../js/admin.js"></script>
    <script>
	
	$(function () {
	new Chart(document.getElementById("pie_chart").getContext("2d"), getChartJs('pie'));
	new Chart(document.getElementById("bar_chart").getContext("2d"), getChartJs('bar'));
    new Chart(document.getElementById("line_chart").getContext("2d"), getChartJs('line'));
    new Chart(document.getElementById("radar_chart").getContext("2d"), getChartJs('radar'));
    
});

function getChartJs(type) {
    var config = null;

    if (type === 'line') {
        config = {
            type: 'line',
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [{
                    label: "My First dataset",
                    data: [65, 59, 80, 81, 56, 55, 40],
                    borderColor: 'rgba(0, 188, 212, 0.75)',
                    backgroundColor: 'rgba(0, 188, 212, 0.3)',
                    pointBorderColor: 'rgba(0, 188, 212, 0)',
                    pointBackgroundColor: 'rgba(0, 188, 212, 0.9)',
                    pointBorderWidth: 1
                }, {
                        label: "My Second dataset",
                        data: [28, 48, 40, 19, 86, 27, 90],
                        borderColor: 'rgba(233, 30, 99, 0.75)',
                        backgroundColor: 'rgba(233, 30, 99, 0.3)',
                        pointBorderColor: 'rgba(233, 30, 99, 0)',
                        pointBackgroundColor: 'rgba(233, 30, 99, 0.9)',
                        pointBorderWidth: 1
                    }]
            },
            options: {
                responsive: true,
                legend: false
            }
        }
    }
    else if (type === 'bar') {
        config = {
            type: 'bar',
            data: {
                <?php
				echo 'labels: [';
				while($row=mysqli_fetch_array($hasil)){
				$prodi[$r]=$row['id_prodi'];
				$kode[$r]=$row['kode'];
				if($r=='0'){
				echo "";
				}else{
					echo ",";
				}
				echo '"'.$kode[$r].'"';
				//ambil data complete
				$query1 = "SELECT remark, count(*) as total FROM tbl_respondent where prody_code='$kode[$r]'"; 
				$result1 = mysqli_query($mysqli, $query1);
				while($row = mysqli_fetch_array($result1))  { 
                               $tot[$r]=$row['total'];
						  }
				$query2 = "SELECT remark, count(*) as total FROM tbl_respondent where prody_code='$kode[$r]' and remark='Complete'"; 
				$result2 = mysqli_query($mysqli, $query2);
				while($row = mysqli_fetch_array($result2))  { 
                               $toti[$r]=$row['total'];
						  }
				$r++;
				}
				echo '],';
				echo 'datasets: [{';
				echo 'label: "Jumlah Tracer",';
				echo 'data: [';
				$o=0;
				for($i=$r;$i>0;$i--){
				if($o==0){
				echo "";
				}else{
					echo ",";
				}
					echo $tot[$o];
					$o++;
				}
				echo '],';
				echo "backgroundColor: 'rgba(233, 30, 99, 0.8)'";
				echo "}, {";
				echo 'label: "Complete",';
				echo 'data: [';
				$p=0;
				for($i=$r;$i>0;$i--){
				if($p==0){
				echo "";
				}else{
					echo ",";
				}
					echo $toti[$p];
					$p++;
				}
				echo '],';
				?>
                      backgroundColor: 'rgba(0, 188, 212, 0.8)'
                    }]
            },
            options: {
                responsive: true,
                legend: false
            }
        }
    }
    else if (type === 'radar') {
        config = {
            type: 'radar',
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [{
                    label: "My First dataset",
                    data: [65, 25, 90, 81, 56, 55, 40],
                    borderColor: 'rgba(0, 188, 212, 0.8)',
                    backgroundColor: 'rgba(0, 188, 212, 0.5)',
                    pointBorderColor: 'rgba(0, 188, 212, 0)',
                    pointBackgroundColor: 'rgba(0, 188, 212, 0.8)',
                    pointBorderWidth: 1
                }, {
                        label: "My Second dataset",
                        data: [72, 48, 40, 19, 96, 27, 100],
                        borderColor: 'rgba(233, 30, 99, 0.8)',
                        backgroundColor: 'rgba(233, 30, 99, 0.5)',
                        pointBorderColor: 'rgba(233, 30, 99, 0)',
                        pointBackgroundColor: 'rgba(233, 30, 99, 0.8)',
                        pointBorderWidth: 1
                    }]
            },
            options: {
                responsive: true,
                legend: false
            }
        }
    }
    else if (type === 'pie') {
        config = {
            type: 'pie',
            data: {
                datasets: [{
                    <?php echo "data: [".$blm.", ".$in.", ".$compl."]," ?>
                    backgroundColor: [
                        "rgb(233, 30, 99)",
                        "rgb(255, 193, 7)",
                        "rgb(0, 188, 212)"
                    ],
                }],
                labels: [
                    "Belum Survey",
                    "In Progress",
                    "Complete"
                ]
            },
            options: {
                responsive: true,
                legend: false
            }
        }
    }
    return config;
}


	
	</script>

    <!-- Demo Js -->
    <script src="../../js/demo.js"></script>
</body>

</html>
<?php
   }else{
	   header('location:../../cdc/index.php');//jika belum login jangan lanjut..
}
}else{
	header('location:../../cdc/index.php');//jika belum login jangan lanjut..
}
?>
