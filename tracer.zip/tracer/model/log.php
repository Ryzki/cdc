<?php

session_start();
include 'set.php';

if($_GET['submit']=="sign"){
	
	$userid = $_GET['username'];
	$psw = md5($_GET['password']);
	
    $sql = "SELECT * FROM user WHERE username='$userid' and password='$psw'";
	$hasil = $mysqli->query($sql) or die ($mysqli->error._LINE_);
	if($hasil->num_rows > 0){
			$_SESSION['userid'] = $userid;
			$_SESSION['psw'] = $psw;
			
			
			//cek dulu apakah admin?
			$sql = "SELECT * FROM user WHERE username='$userid' and password='$psw'";
			$hasil = $mysqli->query($sql) or die ($mysqli->error._LINE_);
			while($row=mysqli_fetch_array($hasil)){
			$lvl=$row['level'];
			$_SESSION['lvl'] = $lvl;
		}
			//echo "direct to main page";
			if($lvl=='admin'){
			header("location:../pages/forms/Adds.php");	
			}else{
			header("location:../pages/charts/chartjs.php");
			}
        }
    else{
       header("location:../pages/examples/sign-in-member.php?error");
	  //echo "salah password";
    }
		
	
}else if($_GET['submit']=="login"){
	$npm = $_GET['npm'];
	$phone = $_GET['phone'];
	$email = $_GET['email'];
	
    $sql = "SELECT * FROM tbl_respondent WHERE npm='$npm'";
	$hasil = $mysqli->query($sql) or die ($mysqli->error._LINE_);
	while($row=mysqli_fetch_array($hasil)){
			$nama=$row['name'];
			$status=$row['status'];
		}
	
    if($hasil->num_rows > 0){
		//buat session
			$_SESSION['npm'] = $npm;
			$_SESSION['nama'] = $nama;
			$_SESSION['email'] = $email;
			$_SESSION['phone'] = $phone;
		
			//update phone dan email
			$update = $mysqli->query("UPDATE tbl_respondent set phone = '$phone' , email = '$email' where npm='$npm'");
           if($update){
			   switch ($status) {
			case 0:
				header("location:../pages/ui/sambutan.php");
				break;
			case 1:
				header("location:../pages/ui/ask2.php");
				break;
			case 2:
				header("location:../pages/ui/ask3.php");
				break;
			case 3:
				header("location:../pages/ui/ask4.php");
				break;
			case 4:
				header("location:../pages/ui/ask5.php");
				break;
			case 5:
				header("location:../pages/ui/ask6.php");
				break;
			case 6:
				header("location:../pages/ui/ask7.php");
				break;
			case 7:
				header("location:../pages/ui/ask8.php");
				break;
			case 8:
				header("location:../pages/ui/ask9.php");
				break;
			case 9:
				header("location:../pages/ui/ask10.php");
				break;
			case 10:
				header("location:../pages/ui/ask11.php");
				break;
			case 11:
				header("location:../pages/ui/ask12.php");
				break;
			case 12:
				header("location:../pages/ui/ask13.php");
				break;
			case 13:
				header("location:../pages/ui/ask14.php");
				break;
			case 14:
				header("location:../pages/ui/ask15.php");
				break;
			case 15:
				header("location:../pages/ui/ask16.php");
				break;
			case 16:
				header("location:../pages/ui/ask17.php");
				break;
			case 17:
				header("location:../pages/ui/ask18.php");
				break;
			case 18:
				header("location:../pages/ui/thanks.php");
				break;
				
			
			default:
				header("location:../model/log.php?submit=out");
				break;
		}
		   }else{
			   header("location:log.php?submit=out");
		   }
				   
        }
    else{
		//die("password salah <a href=\"javascript:history.back()\">kembali</a>");
        header("location:../pages/ui/close.php");
    }
	
}else if($_GET['submit']=="simpan"){
	$kode = $_GET['kode'];
	$prodi = $_GET['prodi'];
	//validasi
	if($kode=="" or $prodi==""){
		header("location:../pages/forms/AddProdi.php?error");
	}else{
	
	//update process
	$sql=$mysqli->query("insert into prodi(kode, prodi) values('$kode','$prodi')");
	if($sql){
							header("location:../pages/tables/ListProdi.php");
					}else{
							header("location:../index.php");
					}
	}
	
}else if($_GET['submit']=="simpan2"){
	$content = $_GET['ckeditor'];
	//update process
	$update=$mysqli->query("update sambutan set content='$content'");
	if($update){
							header("location:../pages/forms/editors.php");
					}else{
							header("location:../index.php");
					}
	
}else if($_GET['submit']=="alumni"){
	$nama = $_GET['nama'];
	$npm = $_GET['npm'];
	$telp = $_GET['telp'];
	$email = $_GET['email'];
	$prodi = $_GET['prodi'];
	$year = $_GET['year'];
	//validasi
	if($nama=="" or $npm=="" or $prodi=="" or $year==""){
		header("location:../pages/tables/AddAlumni.php?error");
	}else{
	//cek dulu apakah data sudah ada di tabel
	$sql = "SELECT * FROM tbl_respondent WHERE npm='$npm'";
	$hasil = $mysqli->query($sql) or die ($mysqli->error._LINE_);
	if($hasil->num_rows > 0){
			
			header("location:../pages/tables/AddAlumni.php?double");
        }else{
	
	//update process
	$sql=$mysqli->query("insert into tbl_respondent(npm, name, phone, email, prody_code, graduation_year) values('$npm','$nama','$telp','$email','$prodi','$year')");
	if($sql){
							header("location:../pages/tables/AddAlumni.php?sukses");
					}else{
							header("location:../index.php");
					}
	}
	}
}else if($_GET['submit']=="registrasi"){
	//cek validasi dulu
				if((empty($_GET['userid'])) or (empty($_GET['password'])) or (empty($_GET['password2'])) or (empty($_GET['select']))){
					header("location:../pages/forms/Adds.php?error");
					
				}else if($_GET['password']<>$_GET['password2']){
					//cek apakah password sama
					header("location:../pages/forms/Adds.php?passwordwrong");
				}
					
	//ini logic add to tabel
	$userid = $_GET['userid'];
	$password = md5($_GET['password']);
	$level = $_GET['select'];
	//input
	$sql=$mysqli->query("insert into user(username, password, level) values('$userid','$password','$level')");
	if($sql){
							header("location:../pages/forms/Adds.php");
					}else{
							header("location:../index.php");
					}
	
}else if(isset($_GET['hapususer'])){
	$username=$_GET['username'];
	$del = $mysqli->query("delete from user where username='$username'"); 
	if($del){
							header("location:../pages/forms/Adds.php");
					}else{
							header("location:../index.php");
					}
}else if(isset($_GET['hapuskode'])){
	echo "OK";
	$kode=$_GET['kode'];
	$del = $mysqli->query("delete from prodi where kode='$kode'"); 
	if($del){
							header("location:../pages/tables/ListProdi.php");
					}else{
							header("location:../index.php");
					}
}else if(isset($_GET['tracer'])){
	$tracer=$_GET['tracer'];
	//logic truncate data
	if($_GET['tracer']==1){
		$busek="TRUNCATE table tbl_questionnaire";
		$truncate = $mysqli->query($busek) or die ($mysqli->error._LINE_); 
		if($truncate){
			header("location:../pages/forms/Clear.php?sukses");
		}else{
			header("location:../pages/forms/Clear.php?gagal");
		}
	}else if($_GET['tracer']==2){
		$busek="TRUNCATE table tbl_respondent";
		$truncate = $mysqli->query($busek) or die ($mysqli->error._LINE_); 
		if($truncate){
			header("location:../pages/forms/Clear.php?sukses");
		}else{
			header("location:../pages/forms/Clear.php?gagal");
		}
	}else{
		$busek="TRUNCATE table prodi";
		$truncate = $mysqli->query($busek) or die ($mysqli->error._LINE_);
		if($truncate){
			header("location:../pages/forms/Clear.php?sukses");
		}else{
			header("location:../pages/forms/Clear.php?gagal");
		}
		
	}
	
}else if($_GET['submit']=="out"){
		unset($_SESSION['npm']);
		unset($_SESSION['nama']);
		unset($_SESSION['email']);
		unset($_SESSION['phone']);
		//menuju halaman utama
		 header("location:../index.php");
	
}else if($_GET['submit']=="outmember"){
		unset($_SESSION['userid']);
		unset($_SESSION['psw']);
		unset($_SESSION['lvl']);
		//menuju halaman utama
		 header("location:../pages/examples/sign-in-member.php");
	
}else{
		header("location:../pages/examples/404.html");
}
?>

