<?php

// Load file koneksi.php
include '../../model/set.php';
//cek apakah sudah login
if(empty($_SESSION['userid'])){
   header('location:../../cdc/index.php');//jika belum login jangan lanjut..
}
if(isset($_POST['import'])){ // Jika user mengklik tombol Import
	$nama_file_baru = 'data.xlsx';

	// Load librari PHPExcel nya
	require_once 'PHPExcel/PHPExcel.php';

	$excelreader = new PHPExcel_Reader_Excel2007();
	$loadexcel = $excelreader->load('tmp/'.$nama_file_baru); // Load file excel yang tadi diupload ke folder tmp
	$sheet = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);

	$numrow = 1;
	foreach($sheet as $row){
		// Ambil data pada excel sesuai Kolom
		$npm = $row['A']; 
		$nama = $row['B']; 
		$phone = $row['C']; 
		$email = $row['D']; 
		$prodi = $row['E']; 
		$year = $row['F']; 
		$status = 0;
		$remark = "Belum Survey";

		// Cek jika semua data tidak diisi
		if(empty($npm) && empty($nama) && empty($phone) && empty($email) && empty($prodi) && empty($year))
			continue; // Lewat data pada baris ini (masuk ke looping selanjutnya / baris selanjutnya)

		// Cek $numrow apakah lebih dari 1
		// Artinya karena baris pertama adalah nama-nama kolom
		// Jadi dilewat saja, tidak usah diimport
		if($numrow > 1){
			// Buat query Insert
			$query = "INSERT INTO tbl_respondent VALUES('".$npm."','".$nama."','".$phone."','".$email."','".$prodi."','".$year."','".$status."','".$remark."')";

			// Eksekusi $query
			mysqli_query($mysqli, $query);
		}

		$numrow++; // Tambah 1 setiap kali looping
	}
}

header('location: ../../cdc/index.php'); // Redirect ke halaman awal
?>
